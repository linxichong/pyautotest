var config = {
  mode: "fixed_servers",
  rules: {
    singleProxy: {
      scheme: "http",
      host: "wrbgw6.cs.oki.co.jp",
      port: 8080
    },
    bypassList: ["*.oki.co.jp", "172.*.*.*", "10.*.*.*", "*.oki-ops.co.jp"]
  }
};

chrome.proxy.settings.set({
  value: config,
  scope: "regular"
}, function () {});

function callbackFn(details) {
  return {
    authCredentials: {
      username: 'zz032876',
      password: "wk830725"
    }
  };
}

chrome.webRequest.onAuthRequired.addListener(
  callbackFn, {
    urls: ["<all_urls>"]
  },
  ['blocking']
);